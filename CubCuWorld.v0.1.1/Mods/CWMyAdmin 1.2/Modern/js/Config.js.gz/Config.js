﻿RequestTimeout = 10000; //10 second timeout
SlowLoginTime = 5000;   //If login takes longer than this, an additional message will appear to say so.

StatusUpdateInterval = 2000;
ChatUpdateInterval = 5000;
VersionUpdateInterval = 10000;

StatusMaxFails = 30; //How many times to fail before giving up
MinPassGrade = 3;