﻿/*Array.prototype.contains = function (element) {
    for (var i in this) {
        if (this[i] == element) {
            return true;
        }
    }

    return false;
};

Array.prototype.first = function () {
    if (this.length > 0) {
        return (this[0]);
    }

    return null;
};

Array.prototype.last = function () {
    if (this.length > 0) {
        return (this[this.length - 1]);
    }

    return null;
};

Array.prototype.clear = function () {
    this = new Array();
};

Array.prototype.where = function (comparison) {
    var result = new Array();

    for (var i in this) {
        if (comparison(this[i])) {
            result[result.length] = this[i];
        }
    }

    return (result);
};*/

/*Array.prototype.sortBy = function (fieldName, desc) {
    if (desc) {
        this = this.sort(function (a, b) {
            return (a[fieldName] < b[fieldName]) ? 1 : (a[fieldName] > b[fieldName]) ? -1 : 0;
        });
    }
    else {
        this = this.sort(function (a, b) {
            return (a[fieldName] < b[fieldName]) ? -1 : (a[fieldName] > b[fieldName]) ? 1 : 0;
        });
    }
};*/

/*Array.prototype.orderBy = Array.prototype.sortBy;

Array.prototype.top = function (amount) {
    var useAmount = (this.length < amount) ? this.length : amount;

    var result = new Array();

    for (var i = 0; i < useAmount; i++) {
        result[i] = this[i];
    }

    return (result);
};

Array.prototype.equals = function (otherArray) {
    if (otherArray.length != this.length) {
        return (false);
    }

    for (var i in this) {
        if (otherArray[i] != this[i]) {
            return (false);
        }
    }

    return (true);
};*/
